package com.robotsfoundation.weatherapp.Model;

import java.util.List;

public class MyList {

    public int dt;
    public Main main;
    public List<Weather> weather;
    public Clouds clouds;
    public Wind wind;
    public Rain rain;
    public Sys sys;
    public String dt_txt;
}
