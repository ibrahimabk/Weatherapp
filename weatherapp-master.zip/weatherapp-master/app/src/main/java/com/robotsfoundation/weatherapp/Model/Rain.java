package com.robotsfoundation.weatherapp.Model;

public class Rain {


}
